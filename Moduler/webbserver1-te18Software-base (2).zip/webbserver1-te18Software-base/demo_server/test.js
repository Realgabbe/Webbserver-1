const dBModule = require('./dBModule.js')

console.log(dBModule.add2(1,2))